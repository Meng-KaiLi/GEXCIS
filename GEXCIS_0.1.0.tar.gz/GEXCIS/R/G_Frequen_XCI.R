#' @title The penalized Fieller's method and the Fieller's method for estimating the degree of the skewness of X chromosome inactivation for genes
#' @description This code can get the point estimate and the penalized point estimate of the degree of the skewness of X chromosome inactivation (denoted as \eqn{\gamma}) of genes, and their confidence intervals based on the Fieller's and penalized Fieller's methods, respectively. Only female subjects are used, either for quantitative traits or qualitative traits, with or without covariates.
#' @usage G_Frequen_XCI(phenotype,genotype,trait_type,phenotype_missing=NA,
#'                      genotype_missing=NA,alpha=0.05)
#'
#' @param phenotype A data frame containing the pedigree information, phenotype and covariates (if any). The pedigree information in the first five columns includes: pedigree ID (pid), individual ID (iid), father ID (fid), mother ID (mid) and sex. The father ID and the mother ID of a founder are both set to be 0. The numerical codes for sex are 0=unknown, 1=male, 2=female. The trait values are in the last column of the data frame. For qualitative traits, the numerical codes are 0=unaffected, 1=affected. If there are covariates, the covariates are located in the sixth to second-to-last columns.
#' @param genotype A data frame containing the pedigree information and genotypes. The pedigree information in the first five columns is consistent with that in the input variable "phenotype". The input variable "genotype" includes the genotype codes for all the SNPs in a gene, which are included in the current dataset. Each genotype is coded as 0, 1 or 2, indicating the number of the minor alleles. 
#' @param trait_type A character string either being "quantitative" or "qualitative", indicating the type of the trait.
#' @param phenotype_missing The input variable "phenotype_missing" is the missing value for the phenotype in the data file, and the default value is NA. It may be 9 in some data files; or other numeric value.
#' @param genotype_missing The input variable "genotype_missing" represents that the codes for the SNPs in the gene are missing, and the default value is NA. It may be 9 in some data files; or other numeric value.
#' @param alpha The significance level, and the default value is 0.05.
#'
#' @details Note that we estimate the degree of the skewness of X chromosome inactivation in the presence of association.
#'
#' @return
#' \item{penalized_point_estimate}{The penalized point estimate of the degree of the skewness of X chromosome inactivation for the gene.}
#' \item{PF_lower}{The lower bound of the confidence interval obtained by the penalized Fieller's method.}
#' \item{PF_upper}{The upper bound of the confidence interval obtained by the penalized Fieller's method.}
#' \item{PF_length}{The length of the confidence interval obtained by the penalized Fieller's method.}
#' \item{point_estimate}{The point estimate of the degree of the skewness of X chromosome inactivation for the gene.}
#' \item{F_lower}{The lower bound of the confidence interval obtained by the Fieller's method.}
#' \item{F_upper}{The upper bound of the confidence interval obtained by the Fieller's method.}
#' \item{F_length}{The length of the confidence interval obtained by the Fieller's method.}
#' \item{F_D}{Indicates whether or not the confidence interval obtained by the Fieller's method is a discontinuous interval, where 0=NO, 1=YES.}
#' @export
#'
#' @references Li, M. K.; Yuan, Y. X.; Zhu, B.; Wang, K. W.;  Fung, W. K.; Zhou, J. Y. Gene-based methods for estimating the degree of the skewness of X chromosome inactivation. 2022
#' @references Wang, P.; Xu, S.; Wang, Y. X.; et al. Penalized Fieller's confidence interval for the ratio of bivariate normal means. Biometrics 2021, 77, 1355-1368.
#' @references Wang, P; Zhang, Y.; Wang, B. Q.; et al. A statistical measure for the skewness of X chromosome inactivation based on case-control design. BMC Bioinformatics 2019, 20, 11.
#' @references Li, B. H.; Yu, W. Y.; Zhou, J. Y. A statistical measure for the skewness of X chromosome inactivation for quantitative traits and its application to the MCTFR data. BMC Genom. Data 2021, 22, 24.
#' @author Meng-Kai Li, Yu-Xin Yuan and Ji-Yuan Zhou
#'
#' @note The interval not containing 1 indicates the skewed X chromosome inactivation (XCI-S), otherwise it suggests the random X chromosome inactivation (XCI-R) or the escape from X chromosome inactivation (XCI-E).
#'
#' @examples
#' 
#' ##example 11:
#' ##quantitative trait with covariate
#' G_Frequen_XCI(phenotype=phenotype1,genotype=genotype1,trait_type="quantitative",
#'               phenotype_missing=NA,genotype_missing=NA,alpha=0.05)
#' #result:
#' #$penalized_point_estimate
#' #[1] 0.4763586
#' #$PF_lower
#' #[1] 0.06569505
#' #$PF_upper
#' #[1] 1.23757
#' #$PF_length
#' #[1] 1.171875
#' #$point_estimate
#' #[1] 0.4786828
#' #$F_lower
#' #[1] 0.06919327
#' #$F_upper
#' #[1] 1.347783
#' #$F_length
#' #[1] 1.27859
#' #$F_D
#' #[1] 0
#'
#' ##example 12:
#' ##quantitative trait without covariate
#' G_Frequen_XCI(phenotype=phenotype2,genotype=genotype1,trait_type="quantitative",
#'               phenotype_missing=NA,genotype_missing=NA,alpha=0.05)
#' #result:
#' #$penalized_point_estimate
#' #[1] 0.4862892
#' #$PF_lower
#' #[1] 0.06740264
#' #$PF_upper
#' #[1] 1.277344
#' #$PF_length
#' #[1] 1.209942
#' #$point_estimate
#' #[1] 0.4888167
#' #F_lower
#' #[1] 0.07121611
#' #$F_upper
#' #[1] 1.401534
#' #$F_length
#' #[1] 1.330318
#' #$F_D
#' #[1] 0
#'
#' ##example 13:
#' ##qualitative trait with covariate
#' G_Frequen_XCI(phenotype=phenotype5,genotype=genotype1,trait_type="qualitative",
#'               phenotype_missing=NA,genotype_missing=NA,alpha=0.05)
#' #result:
#' #$penalized_point_estimate
#' #[1] 0.2934478
#' #$PF_lower
#' #[1] 0
#' #$PF_upper
#' #[1] 0.9289332
#' #$PF_length
#' #[1] 0.9289332
#' #$point_estimate
#' #[1] 0.2950001
#' #$F_lower
#' #[1] 0
#' #$F_upper
#' #[1] 1.013214
#' #$F_length
#' #[1] 1.013214
#' #$F_D
#' #[1] 0
#'
#' ##example 14:
#' ##qualitative trait without covariate
#' G_Frequen_XCI(phenotype=phenotype6,genotype=genotype1,trait_type="qualitative",
#'               phenotype_missing=NA,genotype_missing=NA,alpha=0.05)
#' #result:
#' #$penalized_point_estimate
#' #[1] 0.6241968
#' #$PF_lower
#' #[1] 0
#' #$PF_upper
#' #[1] 2
#' #$PF_length
#' #[1] 2
#' #$point_estimate
#' #[1] 0.6431983
#' #$F_lower
#' #[1] 0
#' #$F_upper
#' #[1] 2
#' #$F_length
#' #[1] 2
#' #$F_D
#' #[1] 0
#'
#' ##example 15:
#' ##quantitative trait with covariate and missing values.
#' ##both "phenotype" and "genotype" contain the missing values (denoted by NA)
#' G_Frequen_XCI(phenotype=phenotype3,genotype=genotype2,trait_type="quantitative",
#'               phenotype_missing=NA,genotype_missing=NA,alpha=0.05)
#' #result:
#' #$penalized_point_estimate
#' #[1] 0.5153325
#' #$PF_lower
#' #[1] 0.0797702
#' #$PF_upper
#' #[1] 1.383422
#' #$PF_length
#' #[1] 1.303651
#' #$point_estimate
#' #[1] 0.5183941
#' #$F_lower
#' #[1] 0.08485905
#' #$F_upper
#' #[1] 1.547297
#' #$F_length
#' #[1] 1.462438
#' #$F_D
#' #[1] 0
#'
#' ##example 16:
#' ##qualitative trait with covariate and missing values.
#' ##both "phenotype" and "genotype" contain the missing values (denoted by NA)
#' G_Frequen_XCI(phenotype=phenotype7,genotype=genotype2,trait_type="qualitative",
#'               phenotype_missing=NA,genotype_missing=NA,alpha=0.05)
#' #result:
#' #$penalized_point_estimate
#' #[1] 0.2896869
#' #$PF_lower
#' #[1] 0
#' #$PF_upper
#' #[1] 0.8723483
#' #$PF_length
#' #[1] 0.8723483
#' #$point_estimate
#' #[1] 0.2909573
#' #$F_lower
#' #[1] 0
#' #$F_upper
#' #[1] 0.9343073
#' #$F_length
#' #[1] 0.9343073
#' #$F_D
#' #[1] 0
#'
#' ##example 17:
#' ##quantitative trait with covariate and missing values.
#' ##both "phenotype" and "genotype" contain the missing values (denoted by 9)
#' G_Frequen_XCI(phenotype=phenotype4,genotype=genotype3,trait_type="quantitative",
#'               phenotype_missing=9,genotype_missing=9,alpha=0.05)
#' #result:
#' #$penalized_point_estimate
#' #[1] 0.5153325
#' #$PF_lower
#' #[1] 0.0797702
#' #$PF_upper
#' #[1] 1.383422
#' #$PF_length
#' #[1] 1.303651
#' #$point_estimate
#' #[1] 0.5183941
#' #$F_lower
#' #[1] 0.08485905
#' #$F_upper
#' #[1] 1.547297
#' #$F_length
#' #[1] 1.462438
#' #$F_D
#' #[1] 0
#'
#'
G_Frequen_XCI<-function(phenotype,genotype,trait_type,phenotype_missing=NA,genotype_missing=NA,alpha=0.05){
  phenotype<-phenotype
  genotype<-genotype
  ##Handling missing values
  phenotype[,6:ncol(phenotype)][phenotype[,6:ncol(phenotype)]==phenotype_missing]<-NA
  genotype[,6:ncol(genotype)][genotype[,6:ncol(genotype)]==genotype_missing]<-NA
  num_delete<-which(!complete.cases(genotype[,6:ncol(genotype)]))
  if(length(num_delete)==0){
    genotype<-genotype
    phenotype<-phenotype
  }
  if(length(num_delete)!=0){
    genotype<-genotype[-num_delete,]
    phenotype<-phenotype[-num_delete,]
  }
  y<-phenotype[,ncol(phenotype)]
  G<-as.matrix(genotype[,c(6:ncol(genotype))])
  G_1<-1*(G>=1)
  G_2<-1*(G==2)
  ##estimated MAF
  MAF<-colSums(G)/(2*nrow(G))
  ##weighting
  weight<-as.matrix(dbeta(MAF,0.5,0.5),ncol(G),1)
  ##burden variable
  gg_1<-as.vector(G_1 %*% weight)
  gg_2<-as.vector(G_2 %*% weight)

  ##Determine the number of covariates
  num_cov<-ncol(phenotype)-6

  ##Select link function based on phenotype type
  if(trait_type=="quantitative"){
    if(num_cov==0){
      result<-glm(y ~ gg_1+gg_2, family = gaussian)
      var_total<-vcov(result)[2:3,2:3]
      betahat1<-summary(result)$coefficients[2,1]
      betahat2<-summary(result)$coefficients[3,1]
    }
    if(num_cov>0){
      x<-as.matrix(phenotype[,6:(ncol(phenotype)-1)])
      result<-glm(y ~ x+gg_1+gg_2, family = gaussian)
      var_total<-vcov(result)[(ncol(x)+2):(ncol(x)+3),(ncol(x)+2):(ncol(x)+3)]
      betahat1<-summary(result)$coefficients[(ncol(x)+2),1]
      betahat2<-summary(result)$coefficients[(ncol(x)+3),1]
    }
  }
  if(trait_type=="qualitative"){
    if(num_cov==0){
      result<-glm(y ~ gg_1+gg_2, family = binomial(link = "logit"))
      var_total<-vcov(result)[2:3,2:3]
      betahat1<-summary(result)$coefficients[2,1]
      betahat2<-summary(result)$coefficients[3,1]
    }
    if(num_cov>0){
      x<-as.matrix(phenotype[,6:(ncol(phenotype)-1)])
      result<-glm(y ~ x+gg_1+gg_2, family = binomial(link = "logit"))
      var_total<-vcov(result)[(ncol(x)+2):(ncol(x)+3),(ncol(x)+2):(ncol(x)+3)]
      betahat1<-summary(result)$coefficients[(ncol(x)+2),1]
      betahat2<-summary(result)$coefficients[(ncol(x)+3),1]
    }
  }

  ##origin estimate of gamma
  rhat<-2*betahat1/(betahat1+betahat2)
  ##truncate the origin estimate to [0, 2]
  rhat0<-rhat*(rhat>=0 & rhat<=2)+0*(rhat<0)+2*(rhat>2)

  ##Fieller's method
  betahat<-(betahat1+betahat2)/2
  var1<-var_total[1,1]
  var2<-var_total[2,2]
  cov <-var_total[1,2]
  A_Fieller<- betahat^2 - 0.25*qchisq(1-alpha,1)*(var1+var2+2*cov)
  B_Fieller<- qchisq(1-alpha,1)*(var1+cov) - 2*betahat1*betahat
  C_Fieller<- betahat1^2 - qchisq(1-alpha,1)*var1
  deta<-B_Fieller^2 - 4*A_Fieller*C_Fieller
  A<-A_Fieller;B<-B_Fieller;C<-C_Fieller
  if(A_Fieller!=0){
    if(deta>0){
      if(A_Fieller>0){
        rL_fieller<- (-B_Fieller-sqrt(deta))/(2*A_Fieller)
        rU_fieller<- (-B_Fieller+sqrt(deta))/(2*A_Fieller)
        I<-0
      }
      else {
        rL_fieller<- (-B_Fieller+sqrt(deta))/(2*A_Fieller)
        rU_fieller<- (-B_Fieller-sqrt(deta))/(2*A_Fieller)
        I<-1
      }
    }
    else if(deta==0){
      if(A_Fieller<0){
        rL_fieller<-(-9)		## -Inf=-9
        rU_fieller<-(9)		## Inf=9
        I<-6
      }
      else if(A_Fieller>0){
        rL_fieller<-rU_fieller<- -B_Fieller/(2*A_Fieller)
        I<-2
      }
    }
    else if(deta<0){
      if(A_Fieller<0){
        rL_fieller<-(-9)		## -Inf=-9
        rU_fieller<-(9)		## Inf=9
        I<-3
      }
      else if(A_Fieller>0){
        rL_fieller<-9		## -Inf=9
        rU_fieller<-9		## Inf=9
        I<-5
      }
    }
  }
  if(A_Fieller==0){
    rL_fieller<-rU_fieller<--C_Fieller/B_Fieller
    I<-4
  }

  ##PF
  mu_n<-betahat1
  mu_d<-betahat
  var_n<-var1
  var_d<-0.25*(var1+var2+2*cov)
  rho<-0.5*(var1+cov)/sqrt(0.25*(var1+var2+2*cov)*var1)
  Penfieller<-PenFieller(mu_n,mu_d,var_n,var_d,rho,con_level=0.95)
  rL_Penfieller<-Penfieller$PenFieller_Lower
  rU_Penfieller<-Penfieller$PenFieller_Upper
  rhat_pf<-Penfieller$PenFieller_value
  rhat0_pf<-rhat_pf*(rhat_pf>=0 & rhat_pf<=2)+0*(rhat_pf<0)+2*(rhat_pf>2)

  ##obtained by Fieller's method
  egamma=rhat0
  ##obtained by PF method
  egamma_pf=rhat0_pf
  L_f_old = rL_fieller
  U_f_old = rU_fieller
  e_I=I
  L_pf_old=rL_Penfieller
  U_pf_old=rU_Penfieller

  fci_label<-0
  if(e_I==1 & L_f_old>0 & U_f_old < 2) {fci_label=1}

  ##Truncated to the interval of the Filler's method to the range 0-2
  if(e_I==0){
    if(U_f_old < 0){
      L_f_new<-L_f_old
      U_f_new<-U_f_old
      length_f<-NA
    }
    if(U_f_old == 0){
      L_f_new<-0
      U_f_new<-0
      length_f<-0
    }
    if(L_f_old>2){
      L_f_new<-L_f_old
      U_f_new<-U_f_old
      length_f<-NA
    }
    if(L_f_old==2){
      L_f_new<-2
      U_f_new<-2
      length_f<-0
    }
    if(L_f_old<=0 & U_f_old >= 2){
      L_f_new<-0
      U_f_new<-2
      length_f<-2
    }
    if(L_f_old>=0 & U_f_old <= 2){
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-U_f_new-L_f_new
    }
    if(L_f_old<0 & U_f_old >= 0 & U_f_old <= 2){
      L_f_new<-0
      U_f_new<- U_f_old
      length_f<-U_f_new
    }
    if(L_f_old>=0 & L_f_old<=2 & U_f_old > 2){
      L_f_new<-L_f_old
      U_f_new<-2
      length_f<-2-L_f_new
    }
  }
  if(e_I==1){
    if(U_f_old <= 0){
      L_f_new<-0
      U_f_new<-2
      length_f<-2
    }
    if(L_f_old>=2){
      L_f_new<-0
      U_f_new<-2
      length_f<-2
    }
    if(L_f_old<0 & U_f_old > 2){
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-NA
    }
    if(L_f_old>=0 & U_f_old <= 2){
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-L_f_new+(2-U_f_new)
    }
    if(L_f_old<0 & U_f_old >= 0 & U_f_old < 2 ){
      L_f_new<- U_f_old
      U_f_new<-2
      length_f<-2-L_f_new
    }
    if(L_f_old<0 & U_f_old ==2){
      L_f_new<-2
      U_f_new<-2
      length_f<-0
    }
    if(L_f_old>0 & L_f_old<=2 & U_f_old >2){
      L_f_new<-0
      U_f_new<-L_f_old
      length_f<-L_f_old
    }
    if(L_f_old==0 & U_f_old >2){
      L_f_new<-0
      U_f_new<-0
      length_f<-0
    }
  }
  if(e_I==2){
    if(0<=L_f_old & L_f_old<=2){
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-0
    }
    else {
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-NA
    }
  }
  if(e_I==6){
    L_f_new<-0
    U_f_new<-2
    length_f<-2
  }
  if(e_I==3){
    L_f_new<-0
    U_f_new<-2
    length_f<-2
  }
  if(e_I==5){
    L_f_new<-L_f_old
    U_f_new<- U_f_old
    length_f<-NA
  }
  if(e_I==4){
    if(0<=L_f_old & L_f_old<=2){
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-0
    }
    else {
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-NA
    }
  }

  ##Truncated to the interval of the PF method to the range 0-2
  if(U_pf_old<0){
    L_pf_new<-L_pf_old
    U_pf_new<-U_pf_old
    length_pf<-NA
  }
  if(U_pf_old==0){
    L_pf_new<-0
    U_pf_new<-0
    length_pf<-0
  }
  if(L_pf_old>2){
    L_pf_new<-L_pf_old
    U_pf_new<-U_pf_old
    length_pf<-NA
  }
  if(L_pf_old==2){
    L_pf_new<-2
    U_pf_new<-2
    length_pf<-0
  }
  if(L_pf_old<=0 & U_pf_old>=2){
    L_pf_new<-0
    U_pf_new<-2
    length_pf<-2
  }
  if(L_pf_old>=0 & U_pf_old<=2){
    L_pf_new<-L_pf_old
    U_pf_new<-U_pf_old
    length_pf<-U_pf_new-L_pf_new
  }
  if(L_pf_old<0 & U_pf_old>=0 & U_pf_old<=2){
    L_pf_new<-0
    U_pf_new<-U_pf_old
    length_pf<-U_pf_new
  }
  if(L_pf_old>=0 & L_pf_old<=2 & U_pf_old>2){
    L_pf_new<-L_pf_old
    U_pf_new<-2
    length_pf<-2-L_pf_new
  }

  list("penalized_point_estimate" = egamma_pf,
       "PF_lower" = L_pf_new,
       "PF_upper" = U_pf_new,
       "PF_length" =length_pf,

       "point_estimate" = egamma,
       "F_lower" = L_f_new,
       "F_upper" = U_f_new,
       "F_length" = length_f,
       "F_D" = fci_label)
}
