#' @title The penalized Fieller's method and the Fieller's method for measuring the degree of the skewness of X chromosome inactivation for genes.
#' @description This code contains two gene-based methods, the penalized Fieller's method and the Fieller's method, for measureing the degree of the skewness of X chromosome inactivation for either quantitative phenotype or qualitative phenotype, with or with covariates using unrelated females subjects.
#' @usage G_Frequen_XCI(phenotype,genotype,phenotype_type,phenotype_missing=NA,
#'                      allele_missing=NA,alpha=0.05)
#'
#' @param phenotype A data frame containing pedigree information, phenotype and covariates (if any).The pedigree information in the first five columns includes: pedigree ID (pid), individual ID (iid), father ID (fid), mother ID (mid) and sex. The father ID and mother ID of founders are both set to 0.The numerical codes for sex are 0=unknown, 1=male, 2=female.The phenotype is in the last column of the data frame. For quality phenotypes, the numerical codes are 0=unaffected, 1=affected.
#' @param genotype A data frame containing pedigree information and genotypes. The pedigree information in the first five columns is consistent with that in the phenotype. The genotype includes the codes for all the loci contained in the gene on X chromosome. Numerical coding 0=dd, 1=Dd, 2=DD, where d represents the normal allele and D represents the mutant allele.
#' @param phenotype_type A character string either being "quantitative" or "qualitative".
#' @param phenotype_missing The input variable "phenotype_missing" is the missing value for the phenotype in the data file, and the default value is NA. It may be 9 in some data files; or other numeric value.
#' @param allele_missing The input variable "allele_missing" represents that the allele contained in the gene is missing, and the default value is NA. It may be 9 in some data files; or other numeric value.
#' @param alpha The significant level, the default value is 0.05.
#'
#' @details Note that we measure the degree of the skewness of X chromosome inactivation in the presence of association.
#'
#' @return
#' \item{PF}{Point estimate of gamma by the penalized Fieller method}
#' \item{PF_lower}{Lower bound of confidence interval obtained by  the penalized Fieller method}
#' \item{PF_upper}{Upper bound of confidence interval obtained by  the penalized Fieller method}
#' \item{PF_length}{Length of confidence interval obtained by  the penalized Fieller method}
#' \item{Fieller}{Point estimate of gamma by the Fieller's method}
#' \item{F_lower}{Lower bound of confidence interval obtained by  the Fieller's method}
#' \item{F_upper}{Upper bound of confidence interval obtained by  the Fieller's method}
#' \item{F_length}{Length of confidence interval obtained by  the Fieller's method}
#' \item{F_D}{Indicates whether the confidence interval obtained by the Fieller's method is a discontinuous interval,where 0=NO, 1=YES.}
#' @export
#'
#' @references Meng-Kai Li, Yu-Xin Yuan, Bin Zhu, Kai-Wen Wang, Wing Kam Fung and Ji-Yuan Zhou.Gene-based methods for estimating the degree of the skewness of X chromosome inactivation. 2022
#' @references Wang P , Xu SQ, Wang YX, et al. Penalized Fieller's confidence interval for the ratio of bivariate normal means. Biometrics 2020;1-14.
#' @references Wang P, Zhang Y, Wang BQ, et al. A statistical measure for the skewness of X chromosome inactivation based on case-control design. BMC Bioinformatics 2019;20(1):11.
#' @references Li BH, Yu WY, Zhou JY. A statistical measure for the skewness of X chromosome inactivation for quantitative traits and its application to the MCTFR data. BMC Genomic Data 2021;22(1):24.
#' @author Meng-Kai Li, Yu-Xin Yuan and Ji-Yuan Zhou
#'
#' @note The interval not containing 1 indicates skewed X chromosome inactivation (XCI), otherwise it suggests random XCI or escapes from XCI.
#'
#' @examples
#' ##example 11:
#' ##quantitative phenotype with covariate
#' G_Frequen_XCI(phenotype=phenotype1,genotype=genotype1,phenotype_type="quantitative",
#'               phenotype_missing=NA,allele_missing=NA,alpha=0.05)
#' #result:
#' $PF
#' [1] 0.4763586
#' $PF_lower
#' [1] 0.06569505
#' $PF_upper
#' [1] 1.23757
#' $PF_length
#' [1] 1.171875
#' $Fieller
#' [1] 0.4786828
#' $F_lower
#' [1] 0.06919327
#' $F_upper
#' [1] 1.347783
#' $F_length
#' [1] 1.27859
#' $F_D
#' [1] 0
#'
#' ##example 12:
#' ##quantitative phenotype without covariate
#' G_Frequen_XCI(phenotype=phenotype2,genotype=genotype1,phenotype_type="quantitative",
#'               phenotype_missing=NA,allele_missing=NA,alpha=0.05)
#' #result:
#' $PF
#' [1] 0.4862892
#' $PF_lower
#' [1] 0.06740264
#' $PF_upper
#' [1] 1.277344
#' $PF_length
#' [1] 1.209942
#' $Fieller
#' [1] 0.4888167
#' $F_lower
#' [1] 0.07121611
#' $F_upper
#' [1] 1.401534
#' $F_length
#' [1] 1.330318
#' $F_D
#' [1] 0
#'
#' ##example 13:
#' ##qualitative phenotype with covariate
#' G_Frequen_XCI(phenotype=phenotype5,genotype=genotype1,phenotype_type="qualitative",
#'               phenotype_missing=NA,allele_missing=NA,alpha=0.05)
#' #result:
#' $PF
#' [1] 0.2934478
#' $PF_lower
#' [1] 0
#' $PF_upper
#' [1] 0.9289332
#' $PF_length
#' [1] 0.9289332
#' $Fieller
#' [1] 0.2950001
#' $F_lower
#' [1] 0
#' $F_upper
#' [1] 1.013214
#' $F_length
#' [1] 1.013214
#' $F_D
#' [1] 0
#'
#' ##example 14:
#' ##qualitative phenotype without covariate
#' G_Frequen_XCI(phenotype=phenotype6,genotype=genotype1,phenotype_type="qualitative",
#'               phenotype_missing=NA,allele_missing=NA,alpha=0.05)
#' #result:
#' $PF
#' [1] 0.6241968
#' $PF_lower
#' [1] 0
#' $PF_upper
#' [1] 2
#' $PF_length
#' [1] 2
#' $Fieller
#' [1] 0.6431983
#' $F_lower
#' [1] 0
#' $F_upper
#' [1] 2
#' $F_length
#' [1] 2
#' $F_D
#' [1] 0
#'
#' ##example 15:
#' ##quantitative phenotype with covariate and missing values.
#' ##Both phenotype and genotype contain the missing value (denoted by NA)
#' G_Frequen_XCI(phenotype=phenotype3,genotype=genotype2,phenotype_type="quantitative",
#'               phenotype_missing=NA,allele_missing=NA,alpha=0.05)
#' #result:
#' $PF
#' [1] 0.5153325
#' $PF_lower
#' [1] 0.0797702
#' $PF_upper
#' [1] 1.383422
#' $PF_length
#' [1] 1.303651
#' $Fieller
#' [1] 0.5183941
#' $F_lower
#' [1] 0.08485905
#' $F_upper
#' [1] 1.547297
#' $F_length
#' [1] 1.462438
#' $F_D
#' [1] 0
#'
#' ##example 16:
#' ##qualitative phenotype with covariate and missing values.
#' ##Both phenotype and genotype contain the missing value (denoted by NA)
#' G_Frequen_XCI(phenotype=phenotype7,genotype=genotype2,phenotype_type="qualitative",
#'               phenotype_missing=NA,allele_missing=NA,alpha=0.05)
#' #result:
#' $PF
#' [1] 0.2896869
#' $PF_lower
#' [1] 0
#' $PF_upper
#' [1] 0.8723483
#' $PF_length
#' [1] 0.8723483
#' $Fieller
#' [1] 0.2909573
#' $F_lower
#' [1] 0
#' $F_upper
#' [1] 0.9343073
#' $F_length
#' [1] 0.9343073
#' $F_D
#' [1] 0
#'
#' ##example 17:
#' ##quantitative phenotype with covariate and missing values.
#' ##Both phenotype and genotype contain the missing value (denoted by 9)
#' G_Frequen_XCI(phenotype=phenotype4,genotype=genotype3,phenotype_type="quantitative",
#'               phenotype_missing=9,allele_missing=9,alpha=0.05)
#' #result:
#' PF
#' [1] 0.5153325
#' $PF_lower
#' [1] 0.0797702
#' $PF_upper
#' [1] 1.383422
#' $PF_length
#' [1] 1.303651
#' $Fieller
#' [1] 0.5183941
#' $F_lower
#' [1] 0.08485905
#' $F_upper
#' [1] 1.547297
#' $F_length
#' [1] 1.462438
#' $F_D
#' [1] 0
#'
#'
G_Frequen_XCI<-function(phenotype,genotype,phenotype_type,phenotype_missing=NA,allele_missing=NA,alpha=0.05){
  phenotype<-phenotype
  genotype<-genotype
  ##Handling missing values
  phenotype[,6:ncol(phenotype)][phenotype[,6:ncol(phenotype)]==phenotype_missing]<-NA
  genotype[,6:ncol(genotype)][genotype[,6:ncol(genotype)]==allele_missing]<-NA
  num_delete<-which(!complete.cases(genotype[,6:ncol(genotype)]))
  if(length(num_delete)==0){
    genotype<-genotype
    phenotype<-phenotype
  }
  if(length(num_delete)!=0){
    genotype<-genotype[-num_delete,]
    phenotype<-phenotype[-num_delete,]
  }
  y<-phenotype[,ncol(phenotype)]
  G<-as.matrix(genotype[,c(6:ncol(genotype))])
  G_1<-1*(G>=1)
  G_2<-1*(G==2)
  ##estimated MAF
  MAF<-colSums(G)/(2*nrow(G))
  ##weighting
  weight<-as.matrix(dbeta(MAF,0.5,0.5),ncol(G),1)
  ##burden variable
  gg_1<-as.vector(G_1 %*% weight)
  gg_2<-as.vector(G_2 %*% weight)

  ##Determine the number of covariates
  num_cov<-ncol(phenotype)-6

  ##Select link function based on phenotype type
  if(phenotype_type=="quantitative"){
    if(num_cov==0){
      result<-glm(y ~ gg_1+gg_2, family = gaussian)
      var_total<-vcov(result)[2:3,2:3]
      betahat1<-summary(result)$coefficients[2,1]
      betahat2<-summary(result)$coefficients[3,1]
    }
    if(num_cov>0){
      x<-as.matrix(phenotype[,6:(ncol(phenotype)-1)])
      result<-glm(y ~ x+gg_1+gg_2, family = gaussian)
      var_total<-vcov(result)[(ncol(x)+2):(ncol(x)+3),(ncol(x)+2):(ncol(x)+3)]
      betahat1<-summary(result)$coefficients[(ncol(x)+2),1]
      betahat2<-summary(result)$coefficients[(ncol(x)+3),1]
    }
  }
  if(phenotype_type=="qualitative"){
    if(num_cov==0){
      result<-glm(y ~ gg_1+gg_2, family = binomial(link = "logit"))
      var_total<-vcov(result)[2:3,2:3]
      betahat1<-summary(result)$coefficients[2,1]
      betahat2<-summary(result)$coefficients[3,1]
    }
    if(num_cov>0){
      x<-as.matrix(phenotype[,6:(ncol(phenotype)-1)])
      result<-glm(y ~ x+gg_1+gg_2, family = binomial(link = "logit"))
      var_total<-vcov(result)[(ncol(x)+2):(ncol(x)+3),(ncol(x)+2):(ncol(x)+3)]
      betahat1<-summary(result)$coefficients[(ncol(x)+2),1]
      betahat2<-summary(result)$coefficients[(ncol(x)+3),1]
    }
  }

  ##origin estimate of gamma
  rhat<-2*betahat1/(betahat1+betahat2)
  ##truncate the origin estimate to [0, 2]
  rhat0<-rhat*(rhat>=0 & rhat<=2)+0*(rhat<0)+2*(rhat>2)

  ##Fieller's method
  betahat<-(betahat1+betahat2)/2
  var1<-var_total[1,1]
  var2<-var_total[2,2]
  cov <-var_total[1,2]
  A_Fieller<- betahat^2 - 0.25*qchisq(1-alpha,1)*(var1+var2+2*cov)
  B_Fieller<- qchisq(1-alpha,1)*(var1+cov) - 2*betahat1*betahat
  C_Fieller<- betahat1^2 - qchisq(1-alpha,1)*var1
  Δ<-B_Fieller^2 - 4*A_Fieller*C_Fieller
  A<-A_Fieller;B<-B_Fieller;C<-C_Fieller
  if(A_Fieller!=0){
    if(Δ>0){
      if(A_Fieller>0){
        rL_fieller<- (-B_Fieller-sqrt(Δ))/(2*A_Fieller)
        rU_fieller<- (-B_Fieller+sqrt(Δ))/(2*A_Fieller)
        I<-0
      }
      else {
        rL_fieller<- (-B_Fieller+sqrt(Δ))/(2*A_Fieller)
        rU_fieller<- (-B_Fieller-sqrt(Δ))/(2*A_Fieller)
        I<-1
      }
    }
    else if(Δ==0){
      if(A_Fieller<0){
        rL_fieller<-(-9)		## -Inf=-9
        rU_fieller<-(9)		## Inf=9
        I<-6
      }
      else if(A_Fieller>0){
        rL_fieller<-rU_fieller<- -B_Fieller/(2*A_Fieller)
        I<-2
      }
    }
    else if(Δ<0){
      if(A_Fieller<0){
        rL_fieller<-(-9)		## -Inf=-9
        rU_fieller<-(9)		## Inf=9
        I<-3
      }
      else if(A_Fieller>0){
        rL_fieller<-9		## -Inf=9
        rU_fieller<-9		## Inf=9
        I<-5
      }
    }
  }
  if(A_Fieller==0){
    rL_fieller<-rU_fieller<--C_Fieller/B_Fieller
    I<-4
  }

  ##PF
  mu_n<-betahat1
  mu_d<-betahat
  var_n<-var1
  var_d<-0.25*(var1+var2+2*cov)
  rho<-0.5*(var1+cov)/sqrt(0.25*(var1+var2+2*cov)*var1)
  Penfieller<-PenFieller(mu_n,mu_d,var_n,var_d,rho,con_level=0.95)
  rL_Penfieller<-Penfieller$PenFieller_Lower
  rU_Penfieller<-Penfieller$PenFieller_Upper
  rhat_pf<-Penfieller$PenFieller_value
  rhat0_pf<-rhat_pf*(rhat_pf>=0 & rhat_pf<=2)+0*(rhat_pf<0)+2*(rhat_pf>2)

  ##obtained by Fieller's method
  egamma=rhat0
  ##obtained by PF method
  egamma_pf=rhat0_pf
  L_f_old = rL_fieller
  U_f_old = rU_fieller
  e_I=I
  L_pf_old=rL_Penfieller
  U_pf_old=rU_Penfieller

  fci_label<-0
  if(e_I==1 & L_f_old>0 & U_f_old < 2) {fci_label=1}

  ##Truncated to the interval of the Filler's method to the range 0-2
  if(e_I==0){
    if(U_f_old < 0){
      L_f_new<-L_f_old
      U_f_new<-U_f_old
      length_f<-NA
    }
    if(U_f_old == 0){
      L_f_new<-0
      U_f_new<-0
      length_f<-0
    }
    if(L_f_old>2){
      L_f_new<-L_f_old
      U_f_new<-U_f_old
      length_f<-NA
    }
    if(L_f_old==2){
      L_f_new<-2
      U_f_new<-2
      length_f<-0
    }
    if(L_f_old<=0 & U_f_old >= 2){
      L_f_new<-0
      U_f_new<-2
      length_f<-2
    }
    if(L_f_old>=0 & U_f_old <= 2){
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-U_f_new-L_f_new
    }
    if(L_f_old<0 & U_f_old >= 0 & U_f_old <= 2){
      L_f_new<-0
      U_f_new<- U_f_old
      length_f<-U_f_new
    }
    if(L_f_old>=0 & L_f_old<=2 & U_f_old > 2){
      L_f_new<-L_f_old
      U_f_new<-2
      length_f<-2-L_f_new
    }
  }
  if(e_I==1){
    if(U_f_old <= 0){
      L_f_new<-0
      U_f_new<-2
      length_f<-2
    }
    if(L_f_old>=2){
      L_f_new<-0
      U_f_new<-2
      length_f<-2
    }
    if(L_f_old<0 & U_f_old > 2){
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-NA
    }
    if(L_f_old>=0 & U_f_old <= 2){
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-L_f_new+(2-U_f_new)
    }
    if(L_f_old<0 & U_f_old >= 0 & U_f_old < 2 ){
      L_f_new<- U_f_old
      U_f_new<-2
      length_f<-2-L_f_new
    }
    if(L_f_old<0 & U_f_old ==2){
      L_f_new<-2
      U_f_new<-2
      length_f<-0
    }
    if(L_f_old>0 & L_f_old<=2 & U_f_old >2){
      L_f_new<-0
      U_f_new<-L_f_old
      length_f<-L_f_old
    }
    if(L_f_old==0 & U_f_old >2){
      L_f_new<-0
      U_f_new<-0
      length_f<-0
    }
  }
  if(e_I==2){
    if(0<=L_f_old & L_f_old<=2){
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-0
    }
    else {
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-NA
    }
  }
  if(e_I==6){
    L_f_new<-0
    U_f_new<-2
    length_f<-2
  }
  if(e_I==3){
    L_f_new<-0
    U_f_new<-2
    length_f<-2
  }
  if(e_I==5){
    L_f_new<-L_f_old
    U_f_new<- U_f_old
    length_f<-NA
  }
  if(e_I==4){
    if(0<=L_f_old & L_f_old<=2){
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-0
    }
    else {
      L_f_new<-L_f_old
      U_f_new<- U_f_old
      length_f<-NA
    }
  }

  ##Truncated to the interval of the PF method to the range 0-2
  if(U_pf_old<0){
    L_pf_new<-L_pf_old
    U_pf_new<-U_pf_old
    length_pf<-NA
  }
  if(U_pf_old==0){
    L_pf_new<-0
    U_pf_new<-0
    length_pf<-0
  }
  if(L_pf_old>2){
    L_pf_new<-L_pf_old
    U_pf_new<-U_pf_old
    length_pf<-NA
  }
  if(L_pf_old==2){
    L_pf_new<-2
    U_pf_new<-2
    length_pf<-0
  }
  if(L_pf_old<=0 & U_pf_old>=2){
    L_pf_new<-0
    U_pf_new<-2
    length_pf<-2
  }
  if(L_pf_old>=0 & U_pf_old<=2){
    L_pf_new<-L_pf_old
    U_pf_new<-U_pf_old
    length_pf<-U_pf_new-L_pf_new
  }
  if(L_pf_old<0 & U_pf_old>=0 & U_pf_old<=2){
    L_pf_new<-0
    U_pf_new<-U_pf_old
    length_pf<-U_pf_new
  }
  if(L_pf_old>=0 & L_pf_old<=2 & U_pf_old>2){
    L_pf_new<-L_pf_old
    U_pf_new<-2
    length_pf<-2-L_pf_new
  }

  list("PF" = egamma_pf,
       "PF_lower" = L_pf_new,
       "PF_upper" = U_pf_new,
       "PF_length" =length_pf,

       "Fieller" = egamma,
       "F_lower" = L_f_new,
       "F_upper" = U_f_new,
       "F_length" = length_f,
       "F_D" = fci_label)
}
