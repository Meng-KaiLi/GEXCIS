#' @title A dataset of simulated quantitative trait
#'
#' @description The pedigree information in the first five columns includes: pedigree ID (pid), individual ID (iid), father ID (fid), mother ID (mid) and sex.
#'
#' @docType data
#' @keywords datasets
#' @name phenotype2
#' @usage phenotype2
#' @format A dataset for 1,000 unrelated female subjects and six variables.
#' \describe{
#' \item{pid}{Pedigree ID.}
#' \item{iid}{Individual ID.}
#' \item{fid}{Father ID.}
#' \item{mid}{Mother ID.}
#' \item{sex}{The genetic sex of the individual, coded as 1 for males and 2 for females, following the PLINK default coding.}
#' \item{y}{A numeric variable of the quantitative trait.}
#' }
NULL
