#' @title A numeric genotype dataset of a gene with 50 SNPs and missing values (denoted by NA)
#'
#' @description A dataset of simulated genotypes with each row as a female subject, and with 5+50 columns, where 50 is the number of the SNPs. The first five columns are: pedigree ID (pid), individual ID (iid), father ID (fid), mother ID (mid) and sex, respectively, which are followed by one column per SNP.
#'
#' @docType data
#' @keywords datasets
#' @name genotype2
#' @usage genotype2
#' @format A dataset for 1,000 unrelated female subjects and 55 variables.
#' \describe{
#' \item{pid}{Pedigree ID.}
#' \item{iid}{Individual ID.}
#' \item{fid}{Father ID.}
#' \item{mid}{Mother ID.}
#' \item{sex}{The genetic sex of the individual, coded as 1 for males and 2 for females, following the PLINK default coding.}
#' \item{SNP}{Each genotype is coded as 0, 1 or 2, indicating the number of the minor alleles.}
#' }
NULL
