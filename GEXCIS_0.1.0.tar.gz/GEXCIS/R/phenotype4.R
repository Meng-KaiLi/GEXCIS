#' @title Quantitative phenotype with covariate and missing values (denoted by 9)
#'
#' @description The pedigree information in the first five columns includes: pedigree ID (pid), individual ID (iid), father ID (fid), mother ID (mid) and sex.
#'
#' @docType data
#' @keywords datasets
#' @name phenotype4
#' @usage phenotype4
#' @format a data for 1000 individuals and 7 variables.
#' \describe{
#' \item{pid}{pedigree ID.}
#' \item{iid}{individual ID.}
#' \item{fid}{father ID.}
#' \item{mid}{mother ID.}
#' \item{sex}{the genetic sex of individuals.}
#' \item{x1}{a numeric variable of covariate.}
#' \item{y}{a numeric variable of quantitative phenotype.}
#' }
NULL
