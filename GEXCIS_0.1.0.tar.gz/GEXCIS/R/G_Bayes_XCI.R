#' @title The Bayesian method for measuring the degree of the skewness of X chromosome inactivation for genes.
#' @description This code contains the gene-based Bayesian method for measuring the degree of the skewness of X chromosome inactivation for either quantitative phenotype or qualitative phenotype, with or without covariates using unrelated female individuals.
#' @usage G_Bayes_XCI(phenotype,genotype,phenotype_type,phenotype_missing=NA,
#'        allele_missing=NA,prior,model_customize=NULL,chains_num=4,
#'        iter_num=5000,warmup_num=2500,acceptance_rate=0.99)
#'
#' @param phenotype A data frame containing pedigree information, phenotype and covariates (if any).The pedigree information in the first five columns includes: pedigree ID (pid), individual ID (iid), father ID (fid), mother ID (mid) and sex. The father ID and mother ID of founders are both set to 0.The numerical codes for sex are 0=unknown, 1=male, 2=female.The phenotype is in the last column of the data frame. For quality phenotypes, the numerical codes are 0=unaffected, 1=affected.
#' @param genotype A data frame containing pedigree information and genotypes. The pedigree information in the first five columns is consistent with that in the phenotype. The genotype includes the codes for all the loci contained in the gene on X chromosome. Numerical coding 0=dd, 1=Dd, 2=DD, where d represents the normal allele and D represents the mutant allele.
#' @param phenotype_type A character string either being "quantitative" or "qualitative".
#' @param phenotype_missing The input variable "phenotype_missing" is the missing value for the phenotype in the data file, and the default value is NA. It may be 9 in some data files; or other numeric value.
#' @param allele_missing The input variable "allele_missing" represents that the allele contained in the gene is missing, and the default value is NA. It may be 9 in some data files; or other numeric value.
#' @param prior A character string either being "normal", "uniform" or "customize". prior="normal" represents the prior distribution of gamma is the normal distribution specified in the paper, that is, gamma~N(1,1), and the prior distribution of other unknown parameters is also consistent with that in the paper; prior="uniform" represents the prior distribution of gamma is the uniform distribution specified in the paper, that is, gamma~U(0,2),  and the prior distribution of other unknown parameters is also consistent with that in the paper; prior="customize" indicates that the user should specify the prior distribution of gamma and other unknown parameters according to the research needs.
#' @param model_customize Bayesian model that satisfies rstan requirements, activated only when priority="customize". The default is NULL. Please see details and example for details.}
#' @param chains_num A positive integer specifying the number of Markov chains. The default is 4.
#' @param iter_num A positive integer specifying the number of iterations for each chain (including warmup). The default is 5000.
#' @param warmup_num A positive integer specifying the number of warmup (also known as burnin) iterations per chain. The number of warmup iterations should be smaller than the number of iterations and the default is 2500.
#' @param acceptance_rate A value between 0 and 1 that represents the target acceptance rate, the default is 0.99.
#'
#' @details Please install the rstan package and make sure it can work before using this function.Note that we measure the degree of the skewness of X chromosome inactivation in the presence of association.The results may be different for different runs, because of the sampling randomness of the HMC algorithm. If the fixed results are wanted, seed number should be set before running the function. Different version of R may lead to different results under the same seed number. The results of the examples given in this file are obtained under the R with version 4.1.1. When the Bayesian model is customize, it should be noted that the covariates are named x1, x2, x3, and so on; the coefficients of the covariates are named beta_1, beta_2, beta_3, and so on.
#'
#' @return
#' \item{Point_Estimate}{The point estimate of the degree of the skewness of X chromosome inactivation for the gene based on the Bayesian method}
#' \item{HPDI_Lower}{The lower bound of the estimated interval}
#' \item{HPDI_Upper}{The upper bound of the estimated interval.}
#' @export
#'
#' @references Meng-Kai Li, Yu-Xin Yuan, Bin Zhu, Kai-Wen Wang, Wing Kam Fung and Ji-Yuan Zhou.Gene-based methods for estimating the degree of the skewness of X chromosome inactivation. 2022
#' @references Annis J, Miller BJ, Palmeri TJ. Bayesian inference with Stan: a tutorial on adding custom distributions. Behav Res Methods 2017;49:863-86.
#' @author Meng-Kai Li, Yu-Xin Yuan and Ji-Yuan Zhou
#'
#' @note The interval not containing 1 indicates skewed X chromosome inactivation (XCI), otherwise it suggests random XCI or escapes from XCI.
#'
#' @examples
#' library(rstan)
#' rstan_options(javascript=FALSE)
#' options(mc.cores = parallel::detectCores())
#' rstan_options(auto_write = TRUE)
#'
#' ##example 1:
#' ##quantitative phenotype with covariate
#' ##the prior distribution of gamma is a normal distribution specified in the paper
#' ##the prior distribution of other unknown parameters is consistent with that in the paper
#' set.seed(123456)
#' G_Bayes_XCI(phenotype=phenotype1,genotype=genotype1,phenotype_type="quantitative",
#'             phenotype_missing=NA,allele_missing=NA,prior="normal",model_customize=NULL,
#'             chains_num=2,iter_num=1000,warmup_num=500,acceptance_rate=0.99)
#' #result:
#' $Point_Estimate
#' [1] 0.4687626
#' $HPDI_Lower
#' [1] 0.1133476
#' $HPDI_Upper
#' [1] 1.235775
#'
#' ##example 2:
#' ##quantitative phenotype with covariate
#' ##the prior distribution of gamma is a uniform distribution specified in the paper
#' ##the prior distribution of other unknown parameters is consistent with that in the paper
#' set.seed(123456)
#' G_Bayes_XCI(phenotype=phenotype1,genotype=genotype1,phenotype_type="quantitative",
#'             phenotype_missing=NA,allele_missing=NA,prior="uniform",model_customize=NULL,
#'             chains_num=2,iter_num=1000,warmup_num=500,acceptance_rate=0.99)
#' #result:
#' $Point_Estimate
#' [1] 0.4411592
#' $HPDI_Lower
#' [1] 0.002059202
#' $HPDI_Upper
#' [1] 1.261761
#'
#' ##example 3:
#' ##quantitative phenotype with covariate
#' ##the prior distribution of gamma or other unknown parameters is customize.
#' ##Users are required to define the prior distribution of each parameter
#' according to the research background, for example:
#' model_customize="
#' data {
#'   int<lower=0> N ;
#'   vector[N] y;
#'   vector[N] x1;
#'   vector[N] gg_1;
#'   vector[N] gg_2;
#' }
#' parameters {
#'   real beta_0;
#'   real beta_1;
#'   real beta_c;
#'   real<lower=0,upper=2> gamma;
#'   real<lower=0> sigma;
#' }
#' model {
#'   vector[N] theta;
#'   theta = beta_0 + beta_1*x1 + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2;
#'   target += normal_lpdf( beta_0 | 0, 100 );
#'   target += normal_lpdf( beta_1 | 0, 10 );
#'   target += normal_lpdf( beta_c | 0, 20 );
#'   target += normal_lpdf( gamma | 1, 2 );
#'   target += exponential_lpdf(sigma | 1);
#'   for(i in 1:N)
#'     target += normal_lpdf( y[i] | theta[i], sigma );
#' }"
#' set.seed(123456)
#' G_Bayes_XCI(phenotype=phenotype1,genotype=genotype1,phenotype_type="quantitative",
#'             phenotype_missing=NA,allele_missing=NA,
#'             prior="customize",model_customize=model_customize,
#'             chains_num=2,iter_num=1000,warmup_num=500,acceptance_rate=0.99)
#' #result:
#' $Point_Estimate
#' [1] 0.4902301
#' $HPDI_Lower
#' [1] 0.05620893
#' $HPDI_Upper
#' [1] 1.320036
#'
#' ##example 4:
#' ##quantitative phenotype without covariate
#' ##the prior distribution of gamma is a normal distribution specified in the paper
#' ##the prior distribution of other unknown parameters is consistent with that in the paper
#' set.seed(123456)
#' G_Bayes_XCI(phenotype=phenotype2,genotype=genotype1,phenotype_type="quantitative",
#'             phenotype_missing=NA,allele_missing=NA,prior="normal",model_customize=NULL,
#'             chains_num=2,iter_num=1000,warmup_num=500,acceptance_rate=0.99)
#' #result:
#' $Point_Estimate
#' [1] 0.5224464
#' $HPDI_Lower
#' [1] 0.04441401
#' $HPDI_Upper
#' [1] 1.35557
#'
#' ##example 5:
#' ##qualitative phenotype with covariate
#' ##the prior distribution of gamma is a normal distribution specified in the paper
#' ##the prior distribution of other unknown parameters is consistent with that in the paper
#' set.seed(123456)
#' G_Bayes_XCI(phenotype=phenotype5,genotype=genotype1,phenotype_type="qualitative",
#'             phenotype_missing=NA,allele_missing=NA,prior="normal",model_customize=NULL,
#'             chains_num=2,iter_num=1000,warmup_num=500,acceptance_rate=0.99)
#' #result:
#' $Point_Estimate
#' [1] 0.3091504
#' $HPDI_Lower
#' [1] 0.002824296
#' $HPDI_Upper
#' [1] 1.121509
#'
#' ##example 6:
#' ##qualitative phenotype without covariate
#' ##the prior distribution of gamma is a uniform distribution specified in the paper
#' ##the prior distribution of other unknown parameters is consistent with that in the paper
#' set.seed(123456)
#' G_Bayes_XCI(phenotype=phenotype6,genotype=genotype1,phenotype_type="qualitative",
#'             phenotype_missing=NA,allele_missing=NA,prior="uniform",model_customize=NULL,
#'             chains_num=2,iter_num=1000,warmup_num=500,acceptance_rate=0.99)
#' #result:
#' $Point_Estimate
#' [1] 0.5869038
#' $HPDI_Lower
#' [1] 4.107076e-05
#' $HPDI_Upper
#' [1] 1.735476
#'
#' ##example 7:
#' ##qualitative phenotype without covariate
#' ##the prior distribution of gamma or other unknown parameters is customize.
#' ##Users are required to define the prior distribution of each parameter
#' according to the research background, for example:
#' model_customize = "
#' data {
#'   int<lower=0> N;
#'   int y[N] ;
#'   vector[N] gg_1;
#'   vector[N] gg_2;
#' }
#' parameters {
#'   real beta_0;
#'   real beta_c;
#'   real<lower=0,upper=2> gamma;
#' }
#' model {
#'   vector[N] theta;
#'   theta = beta_0 + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2;
#'   target += normal_lpdf( beta_0 | 0, 1 );
#'   target += normal_lpdf( beta_c | 0, 20 );
#'   target += normal_lpdf( gamma | 0.5, 2 );
#'   target += bernoulli_logit_lpmf( y | theta );
#' }"
#' set.seed(123456)
#' G_Bayes_XCI(phenotype=phenotype6,genotype=genotype1,phenotype_type="qualitative",
#'             phenotype_missing=NA,allele_missing=NA,
#'             prior="customize",model_customize=model_customize,
#'             chains_num=2,iter_num=1000,warmup_num=500,acceptance_rate=0.99)
#' #result:
#' $Point_Estimate
#' [1] 0.5340016
#' $HPDI_Lower
#' [1] 0.107194
#' $HPDI_Upper
#' [1] 1.705485
#'
#' ##example 8:
#' ##quantitative phenotype with covariate and missing values. Both phenotype
#' and genotype contain the missing value (denoted by NA)
#' ##the prior distribution of gamma is a uniform distribution specified in the paper
#' ##the prior distribution of other unknown parameters is consistent with that in the paper
#' set.seed(123456)
#' G_Bayes_XCI(phenotype=phenotype3,genotype=genotype2,phenotype_type="quantitative",
#'             phenotype_missing=NA,allele_missing=NA,prior="uniform",model_customize=NULL,
#'             chains_num=2,iter_num=1000,warmup_num=500,acceptance_rate=0.99)
#' #result:
#' $Point_Estimate
#' [1] 0.5601698
#' $HPDI_Lower
#' [1] 0.03673035
#' $HPDI_Upper
#' [1] 1.261375
#'
#' ##example 9:
#' ##qualitative phenotype with covariate and missing values. Both phenotype
#' and genotype contain the missing value (denoted by NA)
#' ##the prior distribution of gamma is a uniform distribution specified in the paper
#' ##the prior distribution of other unknown parameters is consistent with that in the paper
#' set.seed(123456)
#' G_Bayes_XCI(phenotype=phenotype7,genotype=genotype2,phenotype_type="qualitative",
#'             phenotype_missing=NA,allele_missing=NA,prior="uniform",model_customize=NULL,
#'             chains_num=2,iter_num=1000,warmup_num=500,acceptance_rate=0.99)
#' #result:
#' $Point_Estimate
#' [1] 0.280913
#' $HPDI_Lower
#' [1] 0.004132392
#' $HPDI_Upper
#' [1] 0.9235037
#'
#' ##example 10:
#' ##quantitative phenotype with covariate and missing values. Both phenotype
#' and genotype contain the missing value (denoted by 9)
#' ##the prior distribution of gamma is a normal distribution specified in the paper
#' ##the prior distribution of other unknown parameters is consistent with that in the paper
#' set.seed(123456)
#' G_Bayes_XCI(phenotype=phenotype4,genotype=genotype3,phenotype_type="quantitative",
#'             phenotype_missing=9,allele_missing=9,prior="normal",model_customize=NULL,
#'             chains_num=2,iter_num=1000,warmup_num=500,acceptance_rate=0.99)
#' #result:
#' $Point_Estimate
#' [1] 0.4528636
#' $HPDI_Lower
#' [1] 0.1132948
#' $HPDI_Upper
#' [1] 1.370303
#'
#'
G_Bayes_XCI<-function(phenotype,genotype,phenotype_type,phenotype_missing=NA,allele_missing=NA,prior,model_customize=NULL,
                      chains_num=4,iter_num=5000,warmup_num=2500,acceptance_rate=0.99){
  phenotype<-phenotype
  genotype<-genotype
  ##Handling missing values
  phenotype[,6:ncol(phenotype)][phenotype[,6:ncol(phenotype)]==phenotype_missing]<-NA
  genotype[,6:ncol(genotype)][genotype[,6:ncol(genotype)]==allele_missing]<-NA
  num_delete1<-which(!complete.cases(phenotype[,6:ncol(phenotype)]))
  num_delete2<-which(!complete.cases(genotype[,6:ncol(genotype)]))
  num_delete<-unique(c(num_delete1,num_delete2))
  if(length(num_delete)==0){
    genotype<-genotype
    phenotype<-phenotype
  }
  if(length(num_delete)!=0){
    genotype<-genotype[-num_delete,]
    phenotype<-phenotype[-num_delete,]
  }
  y<-phenotype[,ncol(phenotype)]
  G<-as.matrix(genotype[,c(6:ncol(genotype))])
  G_1<-1*(G>=1)
  G_2<-1*(G==2)
  MAF<-colSums(G)/(2*nrow(G))
  weight<-as.matrix(dbeta(MAF,0.5,0.5),ncol(G),1)
  gg_1<-as.vector(G_1 %*% weight)
  gg_2<-as.vector(G_2 %*% weight)
  num_cov<-ncol(phenotype)-6

  if(phenotype_type=="quantitative"){
    if(num_cov==0){
      dataList <-list(y=y, N=length(y), gg_1=gg_1, gg_2=gg_2)
      if(prior == "normal"){
        modelString = "
        data {
          int<lower=0> N;
          vector[N] y;
          vector[N] gg_1;
          vector[N] gg_2;
        }
        parameters {
          real beta_0;
          real beta_c;
          real<lower=0,upper=2> gamma;
          real<lower=0> sigma;
        }
        model {
          vector[N] theta;
          theta = beta_0 + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2;
          target += normal_lpdf( beta_0 | 0, 10 );
          target += normal_lpdf( beta_c | 0, 10 );
          target += normal_lpdf( gamma | 1, 1 );
          target += exponential_lpdf(sigma | 1);
          for(i in 1:N)
            target += normal_lpdf( y[i] | theta[i], sigma );
        }"
      }
      else if(prior == "uniform"){
        modelString = "
        data {
          int<lower=0> N;
          vector[N] y;
          vector[N] gg_1;
          vector[N] gg_2;
        }
        parameters {
          real beta_0;
          real beta_c;
          real<lower=0,upper=2> gamma;
          real<lower=0> sigma;
        }
        model {
          vector[N] theta;
          theta = beta_0 + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2;
          target += normal_lpdf( beta_0 | 0, 10 );
          target += normal_lpdf( beta_c | 0, 10 );
          target += uniform_lpdf( gamma | 0, 2 );
          target += exponential_lpdf(sigma | 1);
          for(i in 1:N)
            target += normal_lpdf( y[i] | theta[i], sigma );
        }"
      }
      else if(prior == "customize"){
        modelString = model_customize
      }
    }
    if(num_cov>0){
      x<-phenotype[,6:(ncol(phenotype)-1)]
      cov_name<-paste("x",c(1:num_cov),sep="")
      coe_name<-paste("beta_",c(1:num_cov),sep="")
      dataList<-data.frame(y,gg_1,gg_2,x)
      colnames(dataList)<-c("y","gg_1","gg_2",cov_name)
      dataList<-as.list(dataList)
      dataList$N<-length(y)
      if(prior == "normal"){
        a<-"data {
      int<lower=0> N ;
      vector[N] y;
      vector[N] gg_1;
      vector[N] gg_2;"
        for(i in 1:length(cov_name)){
          a<-paste(a,paste("vector[N] ",cov_name[i],";",sep=""))
        }
        a<-paste(a,"}",sep="")

        b<-"parameters {
        real beta_0;
        real beta_c;
        real<lower=0,upper=2> gamma;
        real<lower=0> sigma;"
        for(i in 1:length(coe_name)){
          b<-paste(b,paste("real ",coe_name[i],";",sep=""))
        }
        b<-paste(b,"}",sep="")

        c<-"model {
        vector[N] theta;
        theta = beta_0 + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2"
        for(i in 1:length(coe_name)){
          c<-paste(c,paste("+",coe_name[i],"*",cov_name[i]))
        }
        c<-paste(c,";")
        c<-paste(c,"target += normal_lpdf( beta_0 | 0, 10 );
        target += normal_lpdf( beta_c | 0, 10 );
        target += normal_lpdf( gamma | 1, 1 );
        target += exponential_lpdf(sigma | 1);
        for(i in 1:N)
          target += normal_lpdf( y[i] | theta[i], sigma );",sep="\n  ")
        for(i in 1:length(coe_name)){
          c<-paste(c,paste("target += normal_lpdf( ",coe_name[i]," | 0, 10 );",sep=""))
        }
        c<-paste(c,"}",sep="")

        modelString=paste(a,b,c,sep="\n  ")
      }
      else if(prior == "uniform"){
        a<-"data {
      int<lower=0> N ;
      vector[N] y;
      vector[N] gg_1;
      vector[N] gg_2;"
        for(i in 1:length(cov_name)){
          a<-paste(a,paste("vector[N] ",cov_name[i],";",sep=""))
        }
        a<-paste(a,"}",sep="")

        b<-"parameters {
        real beta_0;
        real beta_c;
        real<lower=0,upper=2> gamma;
        real<lower=0> sigma;"
        for(i in 1:length(coe_name)){
          b<-paste(b,paste("real ",coe_name[i],";",sep=""))
        }
        b<-paste(b,"}",sep="")

        c<-"model {
        vector[N] theta;
        theta = beta_0 + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2"
        for(i in 1:length(coe_name)){
          c<-paste(c,paste("+",coe_name[i],"*",cov_name[i]))
        }
        c<-paste(c,";")
        c<-paste(c,"target += normal_lpdf( beta_0 | 0, 10 );
        target += normal_lpdf( beta_c | 0, 10 );
        target += uniform_lpdf( gamma | 0, 2 );
        target += exponential_lpdf(sigma | 1);
        for(i in 1:N)
          target += normal_lpdf( y[i] | theta[i], sigma );",sep="\n  ")
        for(i in 1:length(coe_name)){
          c<-paste(c,paste("target += normal_lpdf( ",coe_name[i]," | 0, 10 );",sep=""))
        }
        c<-paste(c,"}",sep="")

        modelString=paste(a,b,c,sep="\n  ")
      }
      else if(prior == "customize"){
        modelString = model_customize
      }
    }
  }

  if(phenotype_type=="qualitative"){
    if(num_cov==0){
      dataList <-list(y=y, N=length(y), gg_1=gg_1, gg_2=gg_2)
      if(prior == "normal"){
        modelString = "
        data {
          int<lower=0> N;
          int y[N] ;
          vector[N] gg_1;
          vector[N] gg_2;
        }
        parameters {
          real beta_0;
          real beta_c;
          real<lower=0,upper=2> gamma;
        }
        model {
          vector[N] theta;
          theta = beta_0 + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2;
          target += normal_lpdf( beta_0 | 0, 10 );
          target += normal_lpdf( beta_c | 0, 10 );
          target += normal_lpdf( gamma | 1, 1 );
          target += bernoulli_logit_lpmf( y | theta );
        }"
      }
      else if(prior == "uniform"){
        modelString = "
        data {
          int<lower=0> N;
          int y[N] ;
          vector[N] gg_1;
          vector[N] gg_2;
        }
        parameters {
          real beta_0;
          real beta_c;
          real<lower=0,upper=2> gamma;
        }
        model {
          vector[N] theta;
          theta = beta_0 + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2;
          target += normal_lpdf( beta_0 | 0, 10 );
          target += normal_lpdf( beta_c | 0, 10 );
          target += uniform_lpdf( gamma | 0, 2 );
          target += bernoulli_logit_lpmf( y | theta );
        }"
      }
      else if(prior == "customize"){
        modelString = model_customize
      }
    }
    if(num_cov>0){
      x<-phenotype[,6:(ncol(phenotype)-1)]
      cov_name<-paste("x",c(1:num_cov),sep="")
      coe_name<-paste("beta_",c(1:num_cov),sep="")
      dataList<-data.frame(y,gg_1,gg_2,x)
      colnames(dataList)<-c("y","gg_1","gg_2",cov_name)
      dataList<-as.list(dataList)
      dataList$N<-length(y)
      if(prior == "normal"){
        a<-"data {
      int<lower=0> N ;
      int y[N] ;
      vector[N] gg_1;
      vector[N] gg_2;"
        for(i in 1:length(cov_name)){
          a<-paste(a,paste("vector[N] ",cov_name[i],";",sep=""))
        }
        a<-paste(a,"}",sep="")

        b<-"parameters {
        real beta_0;
        real beta_c;
        real<lower=0,upper=2> gamma;"
        for(i in 1:length(coe_name)){
          b<-paste(b,paste("real ",coe_name[i],";",sep=""))
        }
        b<-paste(b,"}",sep="")

        c<-"model {
        vector[N] theta;
        theta = beta_0 + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2"
        for(i in 1:length(coe_name)){
          c<-paste(c,paste("+",coe_name[i],"*",cov_name[i]))
        }
        c<-paste(c,";")
        c<-paste(c,"target += normal_lpdf( beta_0 | 0, 10 );
        target += normal_lpdf( beta_c | 0, 10 );
        target += normal_lpdf( gamma | 1, 1 );
        target += bernoulli_logit_lpmf( y | theta );",sep="\n  ")
        for(i in 1:length(coe_name)){
          c<-paste(c,paste("target += normal_lpdf( ",coe_name[i]," | 0, 10 );",sep=""))
        }
        c<-paste(c,"}",sep="")

        modelString=paste(a,b,c,sep="\n  ")
      }
      else if(prior == "uniform"){
        a<-"data {
      int<lower=0> N ;
      int y[N] ;
      vector[N] gg_1;
      vector[N] gg_2;"
        for(i in 1:length(cov_name)){
          a<-paste(a,paste("vector[N] ",cov_name[i],";",sep=""))
        }
        a<-paste(a,"}",sep="")

        b<-"parameters {
        real beta_0;
        real beta_c;
        real<lower=0,upper=2> gamma;"
        for(i in 1:length(coe_name)){
          b<-paste(b,paste("real ",coe_name[i],";",sep=""))
        }
        b<-paste(b,"}",sep="")

        c<-"model {
        vector[N] theta;
        theta = beta_0 + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2"
        for(i in 1:length(coe_name)){
          c<-paste(c,paste("+",coe_name[i],"*",cov_name[i]))
        }
        c<-paste(c,";")
        c<-paste(c,"target += normal_lpdf( beta_0 | 0, 10 );
        target += normal_lpdf( beta_c | 0, 10 );
        target += uniform_lpdf( gamma | 0, 2 );
        target += bernoulli_logit_lpmf( y | theta );",sep="\n  ")
        for(i in 1:length(coe_name)){
          c<-paste(c,paste("target += normal_lpdf( ",coe_name[i]," | 0, 10 );",sep=""))
        }
        c<-paste(c,"}",sep="")

        modelString=paste(a,b,c,sep="\n  ")
      }
      else if(prior == "customize"){
        modelString = model_customize
      }
    }
  }

  stanDso <- stan_model(model_code=modelString)
  Fit<-sampling( object=stanDso, data=dataList,
                 chains=chains_num, iter=iter_num, warmup=warmup_num, thin=1,control = list(adapt_delta = acceptance_rate))
  sam_chain <- extract( Fit, par=c("gamma"))

  Point_Estimate <- modeofHMC(sam_chain$gamma)
  HPDI_Lower <- HPDIofHMC(sam_chain$gamma)[1]
  HPDI_Upper <- HPDIofHMC(sam_chain$gamma)[2]

  list("Point_Estimate"=Point_Estimate,
       "HPDI_Lower"=HPDI_Lower,
       "HPDI_Upper"=HPDI_Upper)
}
