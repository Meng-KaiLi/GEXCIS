#' @title  A function to obtain the mode of the samples
#'
#' @description A function to obtain the mode of the samples.
#' @usage modeofHMC(sam_chain)
#'
#' @param sam_chain A vector contains the samples.
#'
#' @return The modeofHMC() returns a value.
#' @export
#'
#' @references Wen-Yi Yu, Yu Zhang, Meng-Kai Li, Zi-Ying Yang, Wing Kam Fung, Pei-Zhen Zhao and Ji-Yuan Zhou. BEXCIS: Bayesian methods for estimating the degree of the skewness of X chromosome inactivation. 2022
#' @author Wen-Yi Yu and Ji-Yuan Zhou
#' @examples
#' modeofHMC(runif(100,5,50))
#'
modeofHMC <- function(sam_chain){
  dd <- density(sam_chain)
  dd$x[which.max(dd$y)]
}
