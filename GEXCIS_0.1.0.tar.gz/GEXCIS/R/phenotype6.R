#' @title Qualitative phenotype without covariate
#'
#' @description The pedigree information in the first five columns includes: pedigree ID (pid), individual ID (iid), father ID (fid), mother ID (mid) and sex.
#'
#' @docType data
#' @keywords datasets
#' @name phenotype6
#' @usage phenotype6
#' @format a data for 1000 individuals and 6 variables.
#' \describe{
#' \item{pid}{pedigree ID.}
#' \item{iid}{individual ID.}
#' \item{fid}{father ID.}
#' \item{mid}{mother ID.}
#' \item{sex}{the genetic sex of individuals.}
#' \item{y}{a numeric variable of qualitative phenotype: 0=unaffected, 1=affected.}
#' }
NULL
