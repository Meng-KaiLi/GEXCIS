#' @title A function to obtain the highest posterior density interval of the samples
#'
#' @description A function to obtain the highest posterior density interval of the samples.
#'
#' @usage HPDIofHMC(sampleVec,credMass=0.95)
#'
#' @param sampleVec A vector contains the samples.
#' @param credMass  A value between 0 and 1 used to specify the probability of the samples which should be included in an interval, and the default is 0.95.
#'
#' @return A vector contains the lower bound and the upper bound of the highest posterior density interval.
#' @export
#'
#' @references Li, M. K.; Yuan, Y. X.; Zhu, B.; Wang, K. W.;  Fung, W. K.; Zhou, J. Y. Gene-based methods for estimating the degree of the skewness of X chromosome inactivation. 2022
#'
#' @author Meng-Kai Li, Yu-Xin Yuan and Ji-Yuan Zhou
#'
#' @examples HPDIofHMC(rnorm(100,1,1),credMass = 0.95)
#'
#'
HPDIofHMC = function( sampleVec , credMass=0.95 ) {
  sortedsam = sort( sampleVec )
  nsamp <- length( sortedsam )
  gap = round( credMass * nsamp )
  nCIs = nsamp - gap
  init <- 1 : nCIs
  inds <- which.min(sortedsam[init + gap] - sortedsam[init])
  HDImin = sortedsam[ inds ]
  HDImax = sortedsam[ inds + gap ]
  HDIlim = c( HDImin , HDImax )
  return( HDIlim )
}
