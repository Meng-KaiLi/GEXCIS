#' @title A function to obtain the highest posterior density interval of the samples
#'
#' @description A function to obtain the highest posterior density interval of the samples.
#'
#' @usage HPDIofHMC(sampleVec,credMass=0.95)
#'
#' @param sampleVec A vector contains the samples.
#' @param credMass  A value between 0 and 1 that specifies the proportion of samples that should be included in an interval, the default is 0.95.
#'
#' @return A vector contains the lower bound and the upper bound of the highest posterior density interval.
#' @export
#'
#' @references Wen-Yi Yu, Yu Zhang, Meng-Kai Li, Zi-Ying Yang, Wing Kam Fung, Pei-Zhen Zhao and Ji-Yuan Zhou. BEXCIS: Bayesian methods for estimating the degree of the skewness of X chromosome inactivation. 2022
#'
#' @author Wen-Yi Yu and Ji-Yuan Zhou
#'
#' @examples HPDIofHMC(rnorm(100,1,1),credMass = 0.95)
#'
#'
HPDIofHMC = function( sampleVec , credMass=0.95 ) {
  sortedsam = sort( sampleVec )
  nsamp <- length( sortedsam )
  gap = round( credMass * nsamp )
  nCIs = nsamp - gap
  init <- 1 : nCIs
  inds <- which.min(sortedsam[init + gap] - sortedsam[init])
  HDImin = sortedsam[ inds ]
  HDImax = sortedsam[ inds + gap ]
  HDIlim = c( HDImin , HDImax )
  return( HDIlim )
}
