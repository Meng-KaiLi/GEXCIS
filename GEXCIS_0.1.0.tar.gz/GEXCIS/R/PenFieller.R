#' @title A function for obtaining the confidence interval of a ratio by the penalized Fieller's method
#' @description This function is used to calculate the upper and lower limits of the penalized Fieller's confidence interval for the ratio estimate.
#' @usage PenFieller(mu_n,mu_d,var_n,var_d,rho=0,df_n=NULL,df_d=NULL,con_level=0.95)
#'
#' @param mu_n  The estimated mean of the numerator.
#' @param mu_d  The estimated mean of the denominator.
#' @param var_n A positive value gives the estimated variance of the numerator.
#' @param var_d A positive value gives the estimated variance of the denominator.
#' @param rho A value between -1 and 1 that represents the estimated correlation coefficient of the numerator and the denominator.
#' @param df_n  The degree of freedom of the numerator. The default value is NULL.
#' @param df_d  The degree of freedom of the denominator. The default value is NULL.
#' @param con_level The confidence level. Should be between 0 and 1. The default is 0.95.
#'
#' @return
#' \item{PenFieller_value}{The penalized point estimate of the ratio}
#' \item{PenFieller_Lower}{The lower bound of the estimated interval of the penalized Fieller's method}
#' \item{PenFieller_Upper}{The upper bound of the estimated interval of the penalized Fieller's method.}
#' @export
#'
#' @references Wang P , Xu SQ, Wang YX, et al. Penalized Fieller's confidence interval for the ratio of bivariate normal means. Biometrics 2020;1-14.
#' @author Peng Wang
#'
#'
PenFieller<-function(mu_n,mu_d,var_n,var_d,rho=0,df_n=NULL,df_d=NULL,con_level=0.95){
  if(var_n<=0||var_d<=0) stop("Variance should be a positive number!")
  if(abs(rho)>=1) stop("Correlation coefficient should be between -1 and 1!")
  if((class(df_n)!="NULL"&&is.integer(df_n)=="F"&&df_n<=0)||
     (class(df_d)!="NULL"&&is.integer(df_d)=="F"&&df_d<=0))
    stop("Degree of freedom should be a positive integer!")
  if(con_level<=0||con_level>=1) stop("Confidence level should be between 0 and 1!")
  alpha<-1-con_level
  rhat<-mu_n/mu_d
  cov_nd<-rho*sqrt(var_n)*sqrt(var_d)
  if (class(df_n)=="NULL"||class(df_d)=="NULL") t_alpha<-qnorm(1-alpha/2)
  else {
    if (df_n==df_d) df<-df_n
    else df<-(var_n+rhat^2*var_d)^2/(var_n^2/df_n+rhat^2*var_d^2/df_d)
    t_alpha<-qt(1-alpha/2,df) }
  c_p<-t_alpha^2/4
  p_mu_d<-mu_d/2+sign(mu_d)*sqrt(mu_d^2/4+c_p*var_d)
  w<-p_mu_d/(2*p_mu_d-mu_d)
  rt<-mu_n/p_mu_d
  p_mu_n<-w^(-1)*mu_n
  p_var_d<-w^2*var_d
  p_var_n<-w^(-2)*var_n-4*(w^(-1)-1)*rt*cov_nd+4*(1-w)^2*rt^2*var_d
  p_cov_nd<-cov_nd-2*w*(1-w)*rt*var_d
  a<-p_mu_d^2-t_alpha^2*p_var_d
  b<-2*p_cov_nd*t_alpha^2-2*p_mu_n*p_mu_d
  c<-p_mu_n^2-t_alpha^2*p_var_n
  del<-b^2-4*a*c
  Upper<-(-b+sqrt(del))/(2*a)
  Lower<-(-b-sqrt(del))/(2*a)
  value<-p_mu_n/p_mu_d
  list(PenFieller_Upper=Upper,PenFieller_Lower=Lower,PenFieller_value=value)
}
